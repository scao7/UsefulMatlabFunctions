function lineNew = ransacMerge(line, lineBest, options)
